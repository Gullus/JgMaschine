﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Datafox;
using System.Threading;
using System.Diagnostics;

namespace ActiveConnections
{
    public partial class ActiveConnection : Form
    {
        Thread _acceptor;
        volatile bool _acceptorRunning;
        volatile int _port;
        volatile int _timeout;
        volatile int _interval;
        public delegate void InvokeConnectionState(int channelID, int state, int deviceType, int serial);
        string[] deviceName = new string[10];

        public ActiveConnection()
        {
            InitializeComponent();

            // Felder initialisieren
            _acceptor = null;
            _acceptorRunning = false;

            // Gerätebezeichnungen
            deviceName[0] = "PZE-MasterIV";
            deviceName[1] = "ZK-MasterIV";
            deviceName[2] = "BDE-MasterIV";
            deviceName[3] = "Mobil-MasterIV";
            deviceName[4] = "MDE-BoxIV";
            deviceName[5] = "AE-MasterIV";
            deviceName[6] = "TimeboyIV";
            deviceName[7] = "Exklusiv-Line IV";
            deviceName[8] = "Flex-MasterIV";
            deviceName[9] = "MasterIV"; 
        }

        private void ActiveConnection_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (_acceptorRunning == true)
            {
                buttonStartStop_Click(this, null);
            }
        }

        private void buttonStartStop_Click(object sender, EventArgs e)
        {
            if (_acceptorRunning == false)
            {
                // Thread für die Verbindungsüberwachung initialisieren.
                _acceptor = new Thread(ThreadAcceptor);

                // Werte übernehmen
                _port = Convert.ToInt32(textListenPort.Text);
                _timeout = Convert.ToInt32(textTimeout.Text);
                _interval = Convert.ToInt32(textInterval.Text);
                listConnections.Items.Clear();

                // Thread für die Verbindungsüberwachung starten.
                _acceptor.Start();
                while (!_acceptor.IsAlive);

                // Text auf dem Button anpassen
                buttonStartStop.Text = "Aktive Verbindung beenden";

                // Ctrls deaktivieren
                textListenPort.Enabled = false;
                textTimeout.Enabled = false;
                textInterval.Enabled = false;
            }
            else
            {
                // Thread für die Verbindungsüberwachung stoppen.
                _acceptorRunning = false;
                _acceptor.Join();
                _acceptor = null;

                 // Text auf dem Button anpassen
                buttonStartStop.Text = "Aktive Verbindung starten";

                // Ctrls aktivieren
                textListenPort.Enabled = true;
                textTimeout.Enabled = true;
                textInterval.Enabled = true;
           }
        }
        public void ConnectionState(int channelID, int state, int deviceType, int serial)
        {
            ListViewItem lvi = listConnections.Items.Add("", state);
            lvi.SubItems.Add(string.Format("{0}", channelID));
            lvi.SubItems.Add(string.Format("{0:D2}:{1:D2}:{2:D2}", DateTime.Now.Hour, DateTime.Now.Minute, DateTime.Now.Second));
            lvi.SubItems.Add(deviceName[deviceType]);
            lvi.SubItems.Add(string.Format("{0}", serial));
        }

        public void ThreadAcceptor()
        {
            int idx, errorID;
            int channelID, deviceID;
            object[] param;
            StringBuilder infoString = new StringBuilder(255);
            int infoStringLength;
            string[] token;
            string key;
            List<string> devices = new List<string>();

            // Starten der Aktiven Verbindung
            if (DFComDLL.DFCStartActiveConnection("0.0.0.0", _port, 31, _timeout, 60, 10, 0, 0, out errorID) == 0)
            {
                return;
            }

            // Auf eingehende Verbindungen prüfen.
            _acceptorRunning = true;
            while (_acceptorRunning)
            {
                // Gehaltene Verbindungszustände löschen
                for (idx = 0; idx < devices.Count; idx++)
                {
                    // @ -> Symbol bedeutet, Gerät ist Online
                    // # -> Symbol bedeutet, Gerät ist Offline
                    
                    // Annahme Gerät ist Offline.
                    devices[idx] = devices[idx].Replace('@', '#');
                }

                // Aktuelle Verbindungszustände prüfen
                if ((channelID = DFComDLL.DFCGetFirstActiveChannelID()) != -1)
                {
                    do
                    {
                        // Informationen zum Kanal abrufen, aufbereiten und ausgeben.
                        infoStringLength = infoString.Capacity;
                        DFComDLL.DFCGetInfoActiveChannel(channelID, infoString, out infoStringLength);
                        // Vergleichsschlüssel erstellen
                        key = string.Format("#\r{0}\r{1}", channelID, infoString);
                        // Püfen ob bereits regestriert.
                        if (!devices.Contains(key))
                        {
                            // Status auf Online wechseln.
                            key = key.Replace('#', '@');

                            // Eintrag regestrieren und melden
                            devices.Add(key);

                            // Information aufbereiten und an die Oberfläche weitergeben.
                            token = infoString.ToString().Split('\r');
                            if (Convert.ToInt32(token[0]) > deviceName.GetUpperBound(0))
                            {
                                token[0] = "9";
                            }
                            param = new object[4];
                            param[0] = channelID;
                            param[1] = 1;
                            param[2] = Convert.ToInt32(token[0]);
                            param[3] = Convert.ToInt32(token[1]);
                            BeginInvoke(new InvokeConnectionState(ConnectionState), param);

                            // Wartung für diese Verbindung initialisieren
                            Thread service = new Thread(ThreadService);
                            service.Start(channelID);
                        }
                        else
                        {
                            // Gerät ist weiterhin online.
                            devices[devices.IndexOf(key)] = key.Replace('#', '@');
                        }

                    } while ((channelID = DFComDLL.DFCGetNextActiveChannelID(channelID)) != -1);
                }

                // Alle Einträge auf ihre Aktualität prüfen
                foreach (string device in devices)
                {
                    if (IsOnline(device))
                    {
                        continue;
                    }

                    // Gerät ist offline.

                    // Registration aufheben und melden.
                    // Information aufbereiten und an die Oberfläche weitergeben.
                    token = device.Split('\r');
                    if (Convert.ToInt32(token[2]) > deviceName.GetUpperBound(0))
                    {
                        token[2] = "9";
                    }
                    param = new object[4];
                    param[0] = Convert.ToInt32(token[1]);
                    param[1] = 0;
                    param[2] = Convert.ToInt32(token[2]);
                    param[3] = Convert.ToInt32(token[3]);
                    BeginInvoke(new InvokeConnectionState(ConnectionState), param);
                 }

                // Alle als Offline-markierten löschen
                devices.RemoveAll(IsOffline);

                Thread.Sleep(_interval);
            }
            
            // Alle Verbindungen werden geschlossen
            foreach (string device in devices)
            {
                // Registration aufheben und melden.
                // Information aufbereiten und an die Oberfläche weitergeben.
                token = device.Split('\r');
                if (Convert.ToInt32(token[2]) > deviceName.GetUpperBound(0))
                {
                    token[2] = "9";
                }
                param = new object[4];
                param[0] = Convert.ToInt32(token[1]);
                param[1] = 0;
                param[2] = Convert.ToInt32(token[2]);
                param[3] = Convert.ToInt32(token[3]);
                BeginInvoke(new InvokeConnectionState(ConnectionState), param);
            }

            // Stoppen der Aktiven Verbindung
            if (DFComDLL.DFCStopActiveConnection(out errorID) == 0)
            {
                return;
            }
        }

        private bool IsOnline(string device)
        {
            return (device[0] == '@');
        }
        private bool IsOffline(string device)
        {
            return (device[0] == '#');
        }

        public void ThreadService(object data)
        {
            string msg = "Wartung durchführen.";
            if (DFComDLL.DFCComSendMessage((int)data, 254, 5, 0, 1, msg, msg.Length) == 0)
            {
                // Kommunikationsfehler
            }

            // Verbindung ggf. schliessen, wenn Datensätze per HTTP versendet werden sollen.
            //DFComDLL.DFCComClose((int)data);
        }

        private void textListenPort_TextChanged(object sender, EventArgs e)
        {

        }
     }
}
