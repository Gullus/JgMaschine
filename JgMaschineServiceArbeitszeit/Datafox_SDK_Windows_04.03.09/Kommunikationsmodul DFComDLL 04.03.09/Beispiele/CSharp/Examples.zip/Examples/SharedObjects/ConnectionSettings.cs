﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO.Ports;
using System.Xml.Serialization;
using System.Xml;
using System.IO;

namespace Datafox
{
    public partial class FormConnectionSettings : Form
    {
        ConnectionSettings _data;
        ConnectionSettingsSerializer _serializer = new ConnectionSettingsSerializer();

        public FormConnectionSettings()
        {
            InitializeComponent();
        }

        private void FormConnectionSettings_Load(object sender, EventArgs e)
        {
            //#########################
            // Laden der Dialogdaten
            _data = _serializer.Deserialize();
            // Kanalnummer
            numericChannelID.Value = _data.ChannelID;
            // Busnummer
            int idx = comboDeviceID.FindString(Convert.ToString(_data.DeviceID));
            if (idx != -1)
            {
                comboDeviceID.SelectedIndex = idx;
            }
            else
            {
                comboDeviceID.SelectedIndex = 0;
            }
            // Initialisieren der Portauflistung
            listPorts.Items.Clear();
            string[] ports = SerialPort.GetPortNames();
            foreach (string itm in ports)
            {
                listPorts.Items.Add(itm);
            }
            int idxPorts, idxBaud;
            string stringHost, stringPort;
            // Gewählte Tabseite
            if (_data.Values.CommType == _data.DefaultTcpIp.CommType)
            {
                // TcpIp gewählt
                tabSettings.SelectedIndex = 1;
                idxPorts = listPorts.FindString(_data.DefaultSerial.CommString);
                idxBaud = listBaud.FindString(Convert.ToString(_data.DefaultSerial.CommValue));
                stringHost = _data.Values.CommString;
                stringPort = Convert.ToString(_data.Values.CommValue);
            }
            else
            {
                // Seriell gewählt
                tabSettings.SelectedIndex = 0;
                idxPorts = listPorts.FindString(_data.Values.CommString);
                idxBaud = listBaud.FindString(Convert.ToString(_data.Values.CommValue));
                stringHost = _data.DefaultTcpIp.CommString;
                stringPort = Convert.ToString(_data.DefaultTcpIp.CommValue);
            }
            //#########################
            // Seite: tabSerial
            // Gewähltes Port
            if (idxPorts != -1)
            {
                listPorts.SetSelected(idxPorts, true);
            }
            else
            {
                listPorts.SetSelected(0, true);
            }
            // Gewählte Baudrate
            if (idxBaud != -1)
            {
                listBaud.SetSelected(idxBaud, true);
            }
            else
            {
                listBaud.SetSelected(2, true);
            }
            //#########################
            // Seite: tabTcpIp
            // Gewählter TcpIp Host
            textRemoteHost.Text = stringHost;
            // Gewählter TcpIp Port
            textRemotePort.Text = stringPort;
        }
 
        private void buttonOK_Click(object sender, EventArgs e)
        {
            // Speichern der Dialogdaten
            _serializer.Serialize(_data);
            
            // Formular schliessen
            Close();
        }

        private void numericChannelID_ValueChanged(object sender, EventArgs e)
        {
            _data.ChannelID = Convert.ToInt32(numericChannelID.Value);
        }

        private void tabSettings_Selected(object sender, TabControlEventArgs e)
        {
            switch (tabSettings.SelectedIndex)
            {
                case 1:
                    _data.Values = _data.DefaultTcpIp;
                    break;

                default:
                    _data.Values = _data.DefaultSerial;
                    break;
            }
        }

        private void listPorts_SelectedValueChanged(object sender, EventArgs e)
        {
            if (listPorts.SelectedIndex != -1)
            {
                _data.Values.CommString = listPorts.Text;
            }
        }

        private void listBaud_SelectedValueChanged(object sender, EventArgs e)
        {
            if (listBaud.SelectedIndex != -1)
            {
                _data.Values.CommValue = Convert.ToInt32(listBaud.Text);
            }
        }

        private void textRemoteHost_TextChanged(object sender, EventArgs e)
        {
            _data.Values.CommString = textRemoteHost.Text;
        }

        private void textRemotePort_TextChanged(object sender, EventArgs e)
        {
            if (textRemotePort.TextLength == 0)
            {
                _data.Values.CommValue = 0;
            }
            else
            {
                _data.Values.CommValue = Convert.ToInt32(textRemotePort.Text);
            }
        }

 

    }

    public class ConnectionSettings 
    {
        public ConnectionSettings()
        {
            // Standardeinstellung
            ChannelID = 1;
            DeviceID = 254;

            _values = new ValuesData(1, "COM1", 38400, 1000);
            _defaultSerial = new ValuesData(1, "COM1", 38400, 1000);
            _defaultTcpIp = new ValuesData(3, "0.0.0.0", 8000, 3000);
            _commPassword = "";
        }

        int _channelID;
        public int ChannelID
        {
            get { return _channelID; }
            set { _channelID = value; }
        }
        int _deviceID;
        public int DeviceID
        {
            get { return _deviceID; }
            set { _deviceID = value; }
        }
        string _commPassword;
        public string CommPassword
        {
            get { return _commPassword; }
            set { _commPassword = value; }
        }
        public class ValuesData
        {
            public ValuesData()
            {
                this.CommType = 1;
                this.CommString = "COM1";
                this.CommValue = 38400;
                this.CommTimeout = 1000;
            }
            public ValuesData(int CommType, string CommString, int CommValue, int CommTimeout)
            {
                this.CommType = CommType;
                this.CommString = CommString;
                this.CommValue = CommValue;
                this.CommTimeout = CommTimeout;
            }

            int _commType;
            public int CommType
            {
                get { return _commType; }
                set { _commType = value; }
            }
            string _commString;
            public string CommString
            {
                get { return _commString; }
                set { _commString = value; }
            }
            int _commValue;
            public int CommValue
            {
                get { return _commValue; }
                set { _commValue = value; }
            }
            int _commTimeout;
            public int CommTimeout
            {
                get { return _commTimeout; }
                set { _commTimeout = value; }
            }
        }

        ValuesData _values;
        public Datafox.ConnectionSettings.ValuesData Values
        {
            get { return _values; }
            set { _values = value; }
        }
        ValuesData _defaultSerial;
        public Datafox.ConnectionSettings.ValuesData DefaultSerial
        {
            get { return _defaultSerial; }
            set { _defaultSerial = value; }
        }
        ValuesData _defaultTcpIp;
        public Datafox.ConnectionSettings.ValuesData DefaultTcpIp
        {
            get { return _defaultTcpIp; }
            set { _defaultTcpIp = value; }
        }
    }

    public class ConnectionSettingsSerializer : XmlSerializer
    {
        public ConnectionSettingsSerializer() : base(typeof(ConnectionSettings))
        {

        }

        public void Serialize(ConnectionSettings data)
        {
            XmlWriterSettings settings = new XmlWriterSettings();
            settings.Indent = true;
            XmlWriter writer = XmlWriter.Create(Application.CommonAppDataPath + "\\ConnectionSettings.xml", settings);
            base.Serialize(writer, data);
            writer.Close();
         }

        public ConnectionSettings Deserialize()
        {
            ConnectionSettings _data;
            try
            {
                XmlReader reader = XmlReader.Create(Application.CommonAppDataPath + "\\ConnectionSettings.xml");
                _data = (ConnectionSettings)base.Deserialize(reader);
                reader.Close();
            }
            catch (System.Exception ex)
            {
                _data = new ConnectionSettings();
            }

            return _data;
        }
    }
}
