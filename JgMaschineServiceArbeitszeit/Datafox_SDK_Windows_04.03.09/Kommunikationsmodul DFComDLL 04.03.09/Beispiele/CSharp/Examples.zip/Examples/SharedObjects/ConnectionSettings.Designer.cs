﻿namespace Datafox
{
    partial class FormConnectionSettings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tabSettings = new System.Windows.Forms.TabControl();
            this.tabSerial = new System.Windows.Forms.TabPage();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.listBaud = new System.Windows.Forms.ListBox();
            this.listPorts = new System.Windows.Forms.ListBox();
            this.tabTCPIP = new System.Windows.Forms.TabPage();
            this.labelRemotePort = new System.Windows.Forms.Label();
            this.labelRemoteHost = new System.Windows.Forms.Label();
            this.textRemotePort = new System.Windows.Forms.TextBox();
            this.textRemoteHost = new System.Windows.Forms.TextBox();
            this.buttonOK = new System.Windows.Forms.Button();
            this.serialPort = new System.IO.Ports.SerialPort(this.components);
            this.numericChannelID = new System.Windows.Forms.NumericUpDown();
            this.comboDeviceID = new System.Windows.Forms.ComboBox();
            this.labelChannelID = new System.Windows.Forms.Label();
            this.labelDeviceID = new System.Windows.Forms.Label();
            this.toolTCPIP = new System.Windows.Forms.ToolTip(this.components);
            this.labelPassword = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.tabSettings.SuspendLayout();
            this.tabSerial.SuspendLayout();
            this.tabTCPIP.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericChannelID)).BeginInit();
            this.SuspendLayout();
            // 
            // tabSettings
            // 
            this.tabSettings.Controls.Add(this.tabSerial);
            this.tabSettings.Controls.Add(this.tabTCPIP);
            this.tabSettings.Location = new System.Drawing.Point(8, 71);
            this.tabSettings.Name = "tabSettings";
            this.tabSettings.SelectedIndex = 0;
            this.tabSettings.Size = new System.Drawing.Size(350, 187);
            this.tabSettings.TabIndex = 0;
            this.tabSettings.Selected += new System.Windows.Forms.TabControlEventHandler(this.tabSettings_Selected);
            // 
            // tabSerial
            // 
            this.tabSerial.Controls.Add(this.label2);
            this.tabSerial.Controls.Add(this.label1);
            this.tabSerial.Controls.Add(this.listBaud);
            this.tabSerial.Controls.Add(this.listPorts);
            this.tabSerial.Location = new System.Drawing.Point(4, 22);
            this.tabSerial.Name = "tabSerial";
            this.tabSerial.Padding = new System.Windows.Forms.Padding(3);
            this.tabSerial.Size = new System.Drawing.Size(342, 161);
            this.tabSerial.TabIndex = 0;
            this.tabSerial.Text = "Seriell (COM)";
            this.tabSerial.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(146, 6);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Baud :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(5, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(32, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Port :";
            // 
            // listBaud
            // 
            this.listBaud.FormattingEnabled = true;
            this.listBaud.Items.AddRange(new object[] {
            "9600",
            "19200",
            "38400"});
            this.listBaud.Location = new System.Drawing.Point(190, 6);
            this.listBaud.Name = "listBaud";
            this.listBaud.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.listBaud.Size = new System.Drawing.Size(42, 43);
            this.listBaud.TabIndex = 1;
            this.listBaud.SelectedValueChanged += new System.EventHandler(this.listBaud_SelectedValueChanged);
            // 
            // listPorts
            // 
            this.listPorts.FormattingEnabled = true;
            this.listPorts.Location = new System.Drawing.Point(43, 6);
            this.listPorts.Name = "listPorts";
            this.listPorts.Size = new System.Drawing.Size(97, 134);
            this.listPorts.TabIndex = 0;
            this.listPorts.SelectedValueChanged += new System.EventHandler(this.listPorts_SelectedValueChanged);
            // 
            // tabTCPIP
            // 
            this.tabTCPIP.Controls.Add(this.labelRemotePort);
            this.tabTCPIP.Controls.Add(this.labelRemoteHost);
            this.tabTCPIP.Controls.Add(this.textRemotePort);
            this.tabTCPIP.Controls.Add(this.textRemoteHost);
            this.tabTCPIP.Location = new System.Drawing.Point(4, 22);
            this.tabTCPIP.Name = "tabTCPIP";
            this.tabTCPIP.Padding = new System.Windows.Forms.Padding(3);
            this.tabTCPIP.Size = new System.Drawing.Size(342, 161);
            this.tabTCPIP.TabIndex = 1;
            this.tabTCPIP.Text = "TCP/IP";
            this.tabTCPIP.UseVisualStyleBackColor = true;
            // 
            // labelRemotePort
            // 
            this.labelRemotePort.AutoSize = true;
            this.labelRemotePort.Location = new System.Drawing.Point(10, 35);
            this.labelRemotePort.Name = "labelRemotePort";
            this.labelRemotePort.Size = new System.Drawing.Size(32, 13);
            this.labelRemotePort.TabIndex = 3;
            this.labelRemotePort.Text = "Port :";
            // 
            // labelRemoteHost
            // 
            this.labelRemoteHost.AutoSize = true;
            this.labelRemoteHost.Location = new System.Drawing.Point(10, 13);
            this.labelRemoteHost.Name = "labelRemoteHost";
            this.labelRemoteHost.Size = new System.Drawing.Size(35, 13);
            this.labelRemoteHost.TabIndex = 2;
            this.labelRemoteHost.Text = "Host :";
            // 
            // textRemotePort
            // 
            this.textRemotePort.Location = new System.Drawing.Point(45, 32);
            this.textRemotePort.Name = "textRemotePort";
            this.textRemotePort.Size = new System.Drawing.Size(100, 20);
            this.textRemotePort.TabIndex = 1;
            this.textRemotePort.TextChanged += new System.EventHandler(this.textRemotePort_TextChanged);
            // 
            // textRemoteHost
            // 
            this.textRemoteHost.Location = new System.Drawing.Point(45, 6);
            this.textRemoteHost.Name = "textRemoteHost";
            this.textRemoteHost.Size = new System.Drawing.Size(167, 20);
            this.textRemoteHost.TabIndex = 0;
            this.toolTCPIP.SetToolTip(this.textRemoteHost, "Z. B.: 192.168.1.42\r\nOder: device.selfip.net ");
            this.textRemoteHost.TextChanged += new System.EventHandler(this.textRemoteHost_TextChanged);
            // 
            // buttonOK
            // 
            this.buttonOK.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.buttonOK.Location = new System.Drawing.Point(283, 264);
            this.buttonOK.Name = "buttonOK";
            this.buttonOK.Size = new System.Drawing.Size(75, 23);
            this.buttonOK.TabIndex = 1;
            this.buttonOK.Text = "OK";
            this.buttonOK.UseVisualStyleBackColor = true;
            this.buttonOK.Click += new System.EventHandler(this.buttonOK_Click);
            // 
            // numericChannelID
            // 
            this.numericChannelID.Location = new System.Drawing.Point(93, 12);
            this.numericChannelID.Maximum = new decimal(new int[] {
            250,
            0,
            0,
            0});
            this.numericChannelID.Name = "numericChannelID";
            this.numericChannelID.Size = new System.Drawing.Size(73, 20);
            this.numericChannelID.TabIndex = 2;
            this.numericChannelID.ValueChanged += new System.EventHandler(this.numericChannelID_ValueChanged);
            // 
            // comboDeviceID
            // 
            this.comboDeviceID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboDeviceID.FormattingEnabled = true;
            this.comboDeviceID.Items.AddRange(new object[] {
            "254",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30"});
            this.comboDeviceID.Location = new System.Drawing.Point(93, 38);
            this.comboDeviceID.Name = "comboDeviceID";
            this.comboDeviceID.Size = new System.Drawing.Size(73, 21);
            this.comboDeviceID.TabIndex = 3;
            // 
            // labelChannelID
            // 
            this.labelChannelID.AutoSize = true;
            this.labelChannelID.Location = new System.Drawing.Point(10, 14);
            this.labelChannelID.Name = "labelChannelID";
            this.labelChannelID.Size = new System.Drawing.Size(77, 13);
            this.labelChannelID.TabIndex = 4;
            this.labelChannelID.Text = "Kanalnummer :";
            // 
            // labelDeviceID
            // 
            this.labelDeviceID.AutoSize = true;
            this.labelDeviceID.Location = new System.Drawing.Point(10, 41);
            this.labelDeviceID.Name = "labelDeviceID";
            this.labelDeviceID.Size = new System.Drawing.Size(68, 13);
            this.labelDeviceID.TabIndex = 5;
            this.labelDeviceID.Text = "Busnummer :";
            // 
            // toolTCPIP
            // 
            this.toolTCPIP.AutoPopDelay = 10000;
            this.toolTCPIP.InitialDelay = 200;
            this.toolTCPIP.ReshowDelay = 100;
            // 
            // labelPassword
            // 
            this.labelPassword.AutoSize = true;
            this.labelPassword.Location = new System.Drawing.Point(199, 19);
            this.labelPassword.Name = "labelPassword";
            this.labelPassword.Size = new System.Drawing.Size(53, 13);
            this.labelPassword.TabIndex = 6;
            this.labelPassword.Text = "Passwort:";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(254, 16);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 7;
            // 
            // FormConnectionSettings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(365, 293);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.labelPassword);
            this.Controls.Add(this.labelDeviceID);
            this.Controls.Add(this.buttonOK);
            this.Controls.Add(this.labelChannelID);
            this.Controls.Add(this.tabSettings);
            this.Controls.Add(this.comboDeviceID);
            this.Controls.Add(this.numericChannelID);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormConnectionSettings";
            this.Text = "Einstellungen zur Kommunikationsverbindung";
            this.Load += new System.EventHandler(this.FormConnectionSettings_Load);
            this.tabSettings.ResumeLayout(false);
            this.tabSerial.ResumeLayout(false);
            this.tabSerial.PerformLayout();
            this.tabTCPIP.ResumeLayout(false);
            this.tabTCPIP.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericChannelID)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabSettings;
        private System.Windows.Forms.TabPage tabSerial;
        private System.Windows.Forms.TabPage tabTCPIP;
        private System.Windows.Forms.Button buttonOK;
        private System.Windows.Forms.ListBox listBaud;
        private System.Windows.Forms.ListBox listPorts;
        private System.Windows.Forms.TextBox textRemotePort;
        private System.Windows.Forms.TextBox textRemoteHost;
        private System.IO.Ports.SerialPort serialPort;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelRemoteHost;
        private System.Windows.Forms.Label labelRemotePort;
        private System.Windows.Forms.NumericUpDown numericChannelID;
        private System.Windows.Forms.ComboBox comboDeviceID;
        private System.Windows.Forms.Label labelChannelID;
        private System.Windows.Forms.Label labelDeviceID;
        private System.Windows.Forms.ToolTip toolTCPIP;
        private System.Windows.Forms.Label labelPassword;
        private System.Windows.Forms.TextBox textBox1;
    }
}