﻿namespace SetupAndListTransfer
{
    partial class SetupAndListTransfer
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SetupAndListTransfer));
            this.buttonTransfer = new System.Windows.Forms.Button();
            this.textFolderPath = new System.Windows.Forms.TextBox();
            this.folderBrowser = new System.Windows.Forms.FolderBrowserDialog();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.buttonBrowser = new System.Windows.Forms.Button();
            this.progressTransfer = new System.Windows.Forms.ProgressBar();
            this.textHint = new System.Windows.Forms.TextBox();
            this.backgroundTransfer = new System.ComponentModel.BackgroundWorker();
            this.textConnection = new System.Windows.Forms.TextBox();
            this.buttonConnection = new System.Windows.Forms.Button();
            this.listOut = new System.Windows.Forms.ListView();
            this.imageOut = new System.Windows.Forms.ImageList(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.linkListDelete = new System.Windows.Forms.LinkLabel();
            this.label2 = new System.Windows.Forms.Label();
            this.linkListSave = new System.Windows.Forms.LinkLabel();
            this.saveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonTransfer
            // 
            this.buttonTransfer.Location = new System.Drawing.Point(449, 228);
            this.buttonTransfer.Name = "buttonTransfer";
            this.buttonTransfer.Size = new System.Drawing.Size(125, 23);
            this.buttonTransfer.TabIndex = 1;
            this.buttonTransfer.Text = "Übertragung starten";
            this.buttonTransfer.UseVisualStyleBackColor = true;
            this.buttonTransfer.Click += new System.EventHandler(this.buttonTransfer_Click);
            // 
            // textFolderPath
            // 
            this.textFolderPath.Location = new System.Drawing.Point(6, 22);
            this.textFolderPath.Name = "textFolderPath";
            this.textFolderPath.ReadOnly = true;
            this.textFolderPath.Size = new System.Drawing.Size(509, 20);
            this.textFolderPath.TabIndex = 2;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.buttonBrowser);
            this.groupBox1.Controls.Add(this.textFolderPath);
            this.groupBox1.Location = new System.Drawing.Point(14, 168);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(560, 54);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Verzeichnis von Setup- und Listendateien";
            // 
            // buttonBrowser
            // 
            this.buttonBrowser.Location = new System.Drawing.Point(521, 20);
            this.buttonBrowser.Name = "buttonBrowser";
            this.buttonBrowser.Size = new System.Drawing.Size(33, 23);
            this.buttonBrowser.TabIndex = 0;
            this.buttonBrowser.Text = "...";
            this.buttonBrowser.UseVisualStyleBackColor = true;
            this.buttonBrowser.Click += new System.EventHandler(this.buttonBrowser_Click);
            // 
            // progressTransfer
            // 
            this.progressTransfer.Location = new System.Drawing.Point(14, 230);
            this.progressTransfer.Name = "progressTransfer";
            this.progressTransfer.Size = new System.Drawing.Size(429, 21);
            this.progressTransfer.TabIndex = 4;
            // 
            // textHint
            // 
            this.textHint.Location = new System.Drawing.Point(12, 11);
            this.textHint.Multiline = true;
            this.textHint.Name = "textHint";
            this.textHint.ReadOnly = true;
            this.textHint.Size = new System.Drawing.Size(562, 84);
            this.textHint.TabIndex = 5;
            // 
            // backgroundTransfer
            // 
            this.backgroundTransfer.WorkerReportsProgress = true;
            this.backgroundTransfer.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundTransfer_DoWork);
            this.backgroundTransfer.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.backgroundTransfer_RunWorkerCompleted);
            this.backgroundTransfer.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.backgroundTransfer_ProgressChanged);
            // 
            // textConnection
            // 
            this.textConnection.Location = new System.Drawing.Point(14, 101);
            this.textConnection.Multiline = true;
            this.textConnection.Name = "textConnection";
            this.textConnection.ReadOnly = true;
            this.textConnection.Size = new System.Drawing.Size(479, 55);
            this.textConnection.TabIndex = 6;
            // 
            // buttonConnection
            // 
            this.buttonConnection.Location = new System.Drawing.Point(499, 133);
            this.buttonConnection.Name = "buttonConnection";
            this.buttonConnection.Size = new System.Drawing.Size(75, 23);
            this.buttonConnection.TabIndex = 7;
            this.buttonConnection.Text = "Ändern";
            this.buttonConnection.UseVisualStyleBackColor = true;
            this.buttonConnection.Click += new System.EventHandler(this.buttonConnection_Click);
            // 
            // listOut
            // 
            this.listOut.Location = new System.Drawing.Point(14, 257);
            this.listOut.Name = "listOut";
            this.listOut.Size = new System.Drawing.Size(560, 247);
            this.listOut.SmallImageList = this.imageOut;
            this.listOut.TabIndex = 9;
            this.listOut.UseCompatibleStateImageBehavior = false;
            this.listOut.View = System.Windows.Forms.View.Details;
            // 
            // imageOut
            // 
            this.imageOut.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageOut.ImageStream")));
            this.imageOut.TransparentColor = System.Drawing.Color.Transparent;
            this.imageOut.Images.SetKeyName(0, "info.ico");
            this.imageOut.Images.SetKeyName(1, "warning.ico");
            this.imageOut.Images.SetKeyName(2, "error.ico");
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(309, 512);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "Statusanzeige :";
            // 
            // linkListDelete
            // 
            this.linkListDelete.AutoSize = true;
            this.linkListDelete.Location = new System.Drawing.Point(395, 512);
            this.linkListDelete.Name = "linkListDelete";
            this.linkListDelete.Size = new System.Drawing.Size(48, 13);
            this.linkListDelete.TabIndex = 11;
            this.linkListDelete.TabStop = true;
            this.linkListDelete.Text = "Löschen";
            this.linkListDelete.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkListDelete_LinkClicked);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(448, 512);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(28, 13);
            this.label2.TabIndex = 12;
            this.label2.Text = "oder";
            // 
            // linkListSave
            // 
            this.linkListSave.AutoSize = true;
            this.linkListSave.Location = new System.Drawing.Point(482, 512);
            this.linkListSave.Name = "linkListSave";
            this.linkListSave.Size = new System.Drawing.Size(92, 13);
            this.linkListSave.TabIndex = 13;
            this.linkListSave.TabStop = true;
            this.linkListSave.Text = "in Datei speichern";
            this.linkListSave.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkListSave_LinkClicked);
            // 
            // saveFileDialog
            // 
            this.saveFileDialog.DefaultExt = "txt";
            this.saveFileDialog.Filter = "Textdateien|*.txt|Alle Dateien|*.*";
            // 
            // SetupAndListTransfer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(592, 534);
            this.Controls.Add(this.linkListSave);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.linkListDelete);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listOut);
            this.Controls.Add(this.buttonConnection);
            this.Controls.Add(this.textConnection);
            this.Controls.Add(this.textHint);
            this.Controls.Add(this.progressTransfer);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.buttonTransfer);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "SetupAndListTransfer";
            this.Text = "Setup und Listen übertragen.";
            this.Load += new System.EventHandler(this.SetupAndListTransfer_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.SetupAndListTransfer_FormClosing);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonTransfer;
        private System.Windows.Forms.TextBox textFolderPath;
        private System.Windows.Forms.FolderBrowserDialog folderBrowser;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button buttonBrowser;
        private System.Windows.Forms.ProgressBar progressTransfer;
        private System.Windows.Forms.TextBox textHint;
        private System.ComponentModel.BackgroundWorker backgroundTransfer;
        private System.Windows.Forms.TextBox textConnection;
        private System.Windows.Forms.Button buttonConnection;
        private System.Windows.Forms.ListView listOut;
        private System.Windows.Forms.ImageList imageOut;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.LinkLabel linkListDelete;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.LinkLabel linkListSave;
        private System.Windows.Forms.SaveFileDialog saveFileDialog;
    }
}

