﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Serialization;
using Datafox;
using System.IO;

namespace SetupAndListTransfer
{
    public partial class SetupAndListTransfer : Form
    {
        FormConnectionSettings _formConnectionSettings = new FormConnectionSettings();
        TransferSettings _data;
        TransferSettingsSerializer _serializer = new TransferSettingsSerializer();
        ConnectionSettingsSerializer _serializerConnectionSettings = new ConnectionSettingsSerializer();
        public static CBFunction _func;
        int _progressPercentage;

        public SetupAndListTransfer()
        {
            InitializeComponent();

        }

        private void SetupAndListTransfer_Load(object sender, EventArgs e)
        {
            // Beschreibung was die Anwendung macht
            textHint.Text = "Diese Anwendung überträgt die im unten angegebenen Ordner vorliegende Setupdatei mit ggf. zugehörigen Listen auf das angegebene Datafox-Terminal.\r\n\r\nMuster der Setupdatei: *.aes, *.ael\r\nMuster der Listendateien: {Listenname}*.txt";

            // Eingestellte Kommunikation anzeigen
            ShowCurrentConnectionString();

            // Dialog zur Ordnerauswahl initialisieren
            folderBrowser.Description = "Bitte Ordner mit der Setupdatei und Listendateien auswählen:";
            folderBrowser.ShowNewFolderButton = false;

            // Laden des aktuellen Profils
            _data = _serializer.Deserialize();

            // Aktueller Arbeitsordner
            textFolderPath.Text = _data.FolderPath;

            // Aktuelles Arbeitsverzeichnis setzen
            Environment.CurrentDirectory = _data.FolderPath;

            // Spalte der Ausgabeliste erstellen
            listOut.Columns.Add("Meldungen", listOut.ClientSize.Width);

            // Programmstartmeldung 
            listOut.Items.Add(string.Format("Programmstart: {0}", DateTime.Now), 0);
        }

        private void SetupAndListTransfer_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Speichern des aktuellen Profils
            _serializer.Serialize(_data);
        }

        private void ShowCurrentConnectionString()
        {
            StringBuilder sb = new StringBuilder();
            ConnectionSettings settings = _serializerConnectionSettings.Deserialize();
            if (settings.Values.CommType == settings.DefaultSerial.CommType)
            {
                sb.Append("Serielle Kommunikation gewählt:\r\n");
                sb.Append("Port: " + settings.Values.CommString + "\r\n");
                sb.Append("Baud: " + settings.Values.CommValue);
            }
            else if (settings.Values.CommType == settings.DefaultTcpIp.CommType)
            {
                sb.Append("TCP/IP Kommunikation gewählt:\r\n");
                sb.Append("Host: " + settings.Values.CommString + "\r\n");
                sb.Append("Port: " + settings.Values.CommValue);
            }
            else
            {
                sb.Append("Gewählter Kommunikationstyp ist unbekannt.");
            }

            textConnection.Text = sb.ToString();
        }

        private void buttonConnection_Click(object sender, EventArgs e)
        {
            DialogResult result = _formConnectionSettings.ShowDialog(this);
            if (result == DialogResult.OK)
            {
                ShowCurrentConnectionString();
            }
        }

        private void buttonBrowser_Click(object sender, EventArgs e)
        {
            folderBrowser.SelectedPath = _data.FolderPath;
            DialogResult result = folderBrowser.ShowDialog();
            if (result == DialogResult.OK)
            {
                _data.FolderPath = folderBrowser.SelectedPath;
                textFolderPath.Text = _data.FolderPath;

                // Aktuelles Arbeitsverzeichnis
                Environment.CurrentDirectory = _data.FolderPath;
            }
        }


        public class BackgroundTransferSettings
        {
            ConnectionSettings _connectionSettings;
            public Datafox.ConnectionSettings ConnectionSettings
            {
                get { return _connectionSettings; }
                set { _connectionSettings = value; }
            }
            TransferSettings _transferSettings;
            public TransferSettings Settings
            {
                get { return _transferSettings; }
                set { _transferSettings = value; }
            }
            public BackgroundTransferSettings(ConnectionSettings connectionSettings, TransferSettings transferSettings)
            {
                _connectionSettings = connectionSettings;
                _transferSettings = transferSettings;
            }
        }

        private void buttonTransfer_Click(object sender, EventArgs e)
        {
            // Alle Ctrls deaktivieren
            buttonConnection.Enabled = false;
            buttonBrowser.Enabled = false;
            buttonTransfer.Enabled = false;
            // Starten des Übertragungsvorganges
            backgroundTransfer.RunWorkerAsync(new BackgroundTransferSettings(_serializerConnectionSettings.Deserialize(), _data));
        }

        public class TransferState
        {
            public TransferState(StateType type, string message)
            {
                _state = type;
                _message = message;
            }
            public enum StateType { Info, Warning, Error };
            StateType _state;
            public StateType State
            {
                get { return _state; }
                set { _state = value; }
            }
            string _message;
            public string Message
            {
                get { return _message; }
                set { _message = value; }
            }
        }

        private void backgroundTransfer_DoWork(object sender, DoWorkEventArgs e)
        {
            BackgroundWorker worker = (BackgroundWorker)sender;
            BackgroundTransferSettings settings = (BackgroundTransferSettings)e.Argument;
            int channelID = settings.ConnectionSettings.ChannelID;
            int deviceID = settings.ConnectionSettings.DeviceID;
            int errorID, idx, res, listMode = 0, serial;
            StringBuilder errorString = new StringBuilder(255);
            StringBuilder version = new StringBuilder(64);
            string fileName;
            ListImport import = new ListImport();
            int importCount;
            string msg;
            // Ermittlung von zu übertragender Setupdatei.
            string[] files = Directory.GetFiles(_data.FolderPath, "*.aes");
            if (files.Length == 0 || files[0].EndsWith("aes") == false)
            {
                files = Directory.GetFiles(_data.FolderPath, "*.ael");
                if (files.Length == 0 || files[0].EndsWith("ael") == false)
                {
                    msg = string.Format("Es wurde im Verzeichnis [{0}], keine Setupdatei mit der Endung *.aes oder *.ael vorgefunden.\n\nBitte stellen Sie die Verfügbarkeit sicher und starten den Vorgang erneut.", _data.FolderPath);
                    MessageBox.Show(msg, "Setupdatei nicht gefunden!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    // Zustand melden
                    worker.ReportProgress(0, new TransferState(TransferState.StateType.Error, "Keine Setupdatei gefunden."));
                   return;
                }
            }
            if (files.Length > 1)
            {
                msg = string.Format("Im Verzeichnis [{0}] wurden mehrere Setupdateien mit der Endung *.aes oder *.ael vorgefunden.\n\nBitte stellen Sie die Verfügbarkeit von nur einer Setupdatei sicher.", _data.FolderPath);
                MessageBox.Show(msg, "Setupdateien gefunden!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                // Zustand melden
                worker.ReportProgress(0, new TransferState(TransferState.StateType.Error, "Mehrere Setupdateien lagen vor."));
                return;
            }
            // Setupdatei angeben.
            fileName = files[0];

            // Verbindung zu Gerät herstellen
            if (DFComDLL.DFCComOpenIV(channelID, 31, settings.ConnectionSettings.Values.CommType, settings.ConnectionSettings.Values.CommString, settings.ConnectionSettings.Values.CommValue, settings.ConnectionSettings.Values.CommTimeout) == 0)
            {
                msg = string.Format("Schnittstelle oder Verbindung zum Gerät konnte nicht geöffnet werden.\n\nBitte überprüfen Sie die Einstellungen der Kommunikation und Erreichbarkeit des Terminals.");
                MessageBox.Show(msg, "DFCComOpenIV schlug fehl!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                // Zustand melden
                worker.ReportProgress(0, new TransferState(TransferState.StateType.Error, "Verbindung nicht hergestellt."));
                return;
            }

            // Zustand melden
            worker.ReportProgress(0, new TransferState(TransferState.StateType.Info, string.Format("Übertragung startet: {0}", DateTime.Now)));

            _func = ProgressCallBack;
            // Callback zuweisen
            DFComDLL.DFCSetCallBack(channelID, _func);
            do
            {
                // Firmwareversion ermitteln.
                if (DFComDLL.DFCGetVersionFirmware(channelID, deviceID, version, out errorID) == 0)
                {
                    // Fehlertext ermitteln
                    DFComDLL.DFCGetErrorText(channelID, errorID, 0, errorString, errorString.Capacity);
                    // Nachricht anzeigen
                    msg = string.Format("Ermittlung der Firmwareversion ist fehlgeschlagen.\n\nZurückgelieferte Fehlerbeschreibung:\n{0}", errorString);
                    MessageBox.Show(msg, "DFCGetVersionFirmware schlug fehl!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    // Zustand melden
                    worker.ReportProgress(0, new TransferState(TransferState.StateType.Error, "Ermittlung der Firmwareversion schlug fehl."));
                    break;
                }

                // Zustand melden
                worker.ReportProgress(0, new TransferState(TransferState.StateType.Info, string.Format("Firmwareversion: {0}", version)));

                // Seriennummer ermitteln.
                if (DFComDLL.DFCGetSeriennummer(channelID, deviceID, out errorID, out serial) == 0)
                {
                    // Fehlertext ermitteln
                    DFComDLL.DFCGetErrorText(channelID, errorID, 0, errorString, errorString.Capacity);
                    // Nachricht anzeigen
                    msg = string.Format("Ermittlung der Seriennummer ist fehlgeschlagen.\n\nZurückgelieferte Fehlerbeschreibung:\n{0}", errorString);
                    MessageBox.Show(msg, "DFCGetSeriennummer schlug fehl!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    // Zustand melden
                    worker.ReportProgress(0, new TransferState(TransferState.StateType.Error, "Ermittlung der Seriennummer schlug fehl."));
                    break;
                }

                // Zustand melden
                worker.ReportProgress(0, new TransferState(TransferState.StateType.Info, string.Format("Seriennummer: {0}", serial)));
 
                // Setupdatei übertragen
                if (DFComDLL.DFCSetupLaden(channelID, deviceID, fileName, out errorID) == 0)
                {
                    // Fehlertext ermitteln
                    DFComDLL.DFCGetErrorText(channelID, errorID, 0, errorString, errorString.Capacity);
                    // Nachricht anzeigen
                    msg = string.Format("Übertragung der Setupdatei ist fehlgeschlagen.\n\nZurückgelieferte Fehlerbeschreibung:\n{0}", errorString);
                    MessageBox.Show(msg, "DFCSetupLaden schlug fehl!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    // Zustand melden
                    worker.ReportProgress(0, new TransferState(TransferState.StateType.Error, "Setupdatei nicht übertragen."));
                    break;
                }

                // Zustand melden
                worker.ReportProgress(0, new TransferState(TransferState.StateType.Info, "Setupdatei übertragen."));

                do
                {
                    //### Hinweis auf Variable listMode
                    // Die Variable listMode gibt in diesem Bereich an, ob die PZE- oder ZK- Listen abgearbeitet werden.
                    importCount = 0;

                    if (listMode == 0)
                    {
                        // Zustand melden
                        worker.ReportProgress(0, new TransferState(TransferState.StateType.Info, "Listendaten"));
                    }
                    else
                    {
                        // Zustand melden
                        worker.ReportProgress(0, new TransferState(TransferState.StateType.Info, "Listendaten der Zutrittskontrolle"));
                    }


                    // Listenbeschreibung für den Import zurücklesen.
                    TableDeclarations lists = new TableDeclarations((listMode == 0) ? TableDeclarations.TableType.List : TableDeclarations.TableType.ListZK2, "Lists.xml");
                    if (lists.LoadFromDevice(channelID, deviceID, "") == false)
                    {
                        // Fehlertext ermitteln
                        DFComDLL.DFCGetErrorText(channelID, errorID, 0, errorString, errorString.Capacity);
                        // Nachricht anzeigen
                        msg = string.Format("Lesen der Listenbeschreibung ist fehlgeschlagen.\n\nZurückgelieferte Fehlerbeschreibung:\n{0}", errorString);
                        MessageBox.Show(msg, "DFCLoadListenbeschreibung schlug fehl!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                        // Zustand melden
                        worker.ReportProgress(0, new TransferState(TransferState.StateType.Error, "Listenbeschreibung nicht gelesen."));
                        if (listMode == 0)
                        {
                            // Auf Listenmodus ZK wechseln.
                            listMode++;
                            continue;
                        }
                        break;
                    }
                    if (lists.Tables == null)
                    {
                        // Es liegen keine Listenbeschreibungen vor.
                        // Zustand melden
                        worker.ReportProgress(0, new TransferState(TransferState.StateType.Info, "Es liegen keine Listendefinitionen im Setup vor."));
                        // Zustand melden
                        worker.ReportProgress(0, new TransferState(TransferState.StateType.Info, string.Format("Übertragung beendet: {0}", DateTime.Now)));
                        if (listMode == 0)
                        {
                            // Auf Listenmodus ZK wechseln.
                            listMode++;
                            continue;
                        }
                        break;
                    }
                    // Import der Listendaten
                    if (listMode == 0)
                    {
                        DFComDLL.DFCClrListenBuffer(channelID);
                    }
                    else
                    {
                        DFComDLL.DFCClearEntrance2ListBuffer(channelID, -1);
                    }
                    // Vorliegende Listendaten importieren und übertragen.
                    for (idx = 0; idx < lists.Tables.Length; idx++)
                    {
                        fileName = string.Format("{0}*.txt", lists.Tables[idx].Name);
                        files = Directory.GetFiles(settings.Settings.FolderPath, fileName);
                        if (files.Length == 0 || files[0].EndsWith("txt") == false)
                        {
                            if (listMode == 0)
                            {
                                // Keine oder mehrere zugehörige Listendatei gefunden
                                msg = string.Format("Für Liste [{0}] liegt keine Listendatei vor.", lists.Tables[idx].Name);
                                // Zustand melden
                                worker.ReportProgress(0, new TransferState(TransferState.StateType.Warning, msg));
                            }
                            continue;
                        }
                        if (files.Length > 1)
                        {
                            // Keine oder mehrere zugehörige Listendatei gefunden
                            msg = string.Format("Für Liste [{0}] liegen mehrere Listendateien vor.", lists.Tables[idx].Name);
                            // Zustand melden
                            worker.ReportProgress(0, new TransferState(TransferState.StateType.Warning, msg));
                            continue;
                        }
                        try
                        {
                            // Importieren der Listendaten
                            import.Import(lists.Tables[idx], files[0]);
                            if (listMode == 0)
                            {
                                res = DFComDLL.DFCMakeListe(channelID, idx, import.RecordCount, import.Size, import.Mem, 0);
                            }
                            else
                            {
                                res = DFComDLL.DFCMakeEntrance2List(channelID, idx, import.RecordCount, import.Size, import.Mem, out errorID);
                            }
                            if (res == 0)
                            {
                                msg = string.Format("Übergabe der Listendaten aus der Datei [{0}] ist fehlgeschlagen.", files[0]);
                                MessageBox.Show(msg, "DFCMakeListe schlug fehl!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                                // Zustand melden
                                worker.ReportProgress(0, new TransferState(TransferState.StateType.Error, string.Format("Listenübergabe [{0}] gescheitert.", files[0])));
                                continue;
                            }
                            msg = string.Format("Liste [{0} (Datensätze: {1})] wurde importiert. Datei: {2}", lists.Tables[idx].Name, import.RecordCount, files[0]);
                            // Zustand melden
                            worker.ReportProgress(0, new TransferState(TransferState.StateType.Info, msg));

                            // Anzahl importierter Listen halten
                            importCount++;
                        }
                        catch (ListImportException ex)
                        {
                            MessageBox.Show(ex.Message, "Import schlug fehl!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                            msg = string.Format("Import von Liste [{0}] schlug fehl. Datei: {1}", lists.Tables[idx].Name, files[0]);
                            // Zustand melden
                            worker.ReportProgress(0, new TransferState(TransferState.StateType.Warning, msg));
                            continue;
                        }
                    }
                    // Liegen importierte Listen vor?
                    if (importCount == 0)
                    {
                        // Zustand melden
                        if (listMode == 0)
                        {
                            worker.ReportProgress(0, new TransferState(TransferState.StateType.Warning, "Es liegen keine Listendaten vor."));
                        }
                        // Zustand melden
                        worker.ReportProgress(0, new TransferState(TransferState.StateType.Info, string.Format("Übertragung beendet: {0}", DateTime.Now)));
                        if (listMode == 0)
                        {
                            // Auf Listenmodus ZK wechseln.
                            listMode++;
                            continue;
                        }
                        break;
                    }
                    // Laden aller importierter Listendaten
                    if (listMode == 0)
                    {
                        res = DFComDLL.DFCLoadListen(channelID, deviceID, out errorID);
                    }
                    else
                    {
                        res = DFComDLL.DFCLoadEntrance2List(channelID, deviceID, -1, out errorID);
                        if (res == 0 && errorID == 28)
                        {
                            // Zutrittskontrolle ist deaktiviert.
                            errorID = 39;
                        }
                    }
                    if (res == 0)
                    {
                        // Fehlertext ermitteln
                        DFComDLL.DFCGetErrorText(channelID, errorID, 0, errorString, errorString.Capacity);
                        // Nachricht anzeigen
                        msg = string.Format("Übertragung der Listendaten ist fehlgeschlagen.\n\nZurückgelieferte Fehlerbeschreibung:\n{0}", errorString);
                        MessageBox.Show(msg, "DFCLoadListen schlug fehl!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                        // Zustand melden
                        worker.ReportProgress(0, new TransferState(TransferState.StateType.Error, "Listen nicht übertragen."));
                        if (listMode == 0)
                        {
                            // Auf Listenmodus ZK wechseln.
                            listMode++;
                            continue;
                        }
                        break;
                    }
                    msg = string.Format("Es wurde{0} {1} von {2} Listen übertragen.", (importCount == 1) ? "" : "n", importCount, lists.Tables.Length);
                    // Zustand melden
                    worker.ReportProgress(0, new TransferState(TransferState.StateType.Info, msg));

                    // Auf Listenmodus ZK wechseln.
                    listMode++;

                } while (listMode < 2);

                // Zustand melden
                worker.ReportProgress(0, new TransferState(TransferState.StateType.Info, string.Format("Übertragung beendet: {0}", DateTime.Now)));
            } while (false);

            // Verbindung schliessen
            DFComDLL.DFCComClose(channelID);
        }

        public int ProgressCallBack()
        {
            backgroundTransfer.ReportProgress(_progressPercentage++);
            if (_progressPercentage >= 100)
            {
                _progressPercentage = 0;
            }
            return 1;
        }

        private void backgroundTransfer_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            progressTransfer.Value = e.ProgressPercentage;
           if (e.UserState != null)
            {
                TransferState state = (TransferState)e.UserState;
                listOut.Items.Insert(0, state.Message, (int)state.State);
            }
        }

        private void backgroundTransfer_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            // Alle Ctrls deaktivieren
            buttonConnection.Enabled = true;
            buttonBrowser.Enabled = true;
            buttonTransfer.Enabled = true;
        }

        private void linkListDelete_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            listOut.Items.Clear();
        }

        private void linkListSave_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (listOut.Items.Count == 0)
            {
                MessageBox.Show("Keine Einträge zu speichern.");
                return;
            }

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                using (TextWriter writer = new StreamWriter(saveFileDialog.FileName))
                {
                    int idx = listOut.Items.Count - 1;
                    for (; idx != 0; idx--)
                    {
                        writer.WriteLine(listOut.Items[idx].Text);
                    }
                    writer.Close();
                }
            }
        }
     }

    public class TransferSettings
    {
        public TransferSettings()
        {
            _folderPath = Environment.CurrentDirectory;
        }
        string _folderPath;
        public string FolderPath
        {
            get { return _folderPath; }
            set { _folderPath = value; }
        }
    }

    public class TransferSettingsSerializer : XmlSerializer
    {
        public TransferSettingsSerializer()
            : base(typeof(TransferSettings))
        {

        }

        public void Serialize(TransferSettings data)
        {
            XmlWriterSettings settings = new XmlWriterSettings();
            settings.Indent = true;
            XmlWriter writer = XmlWriter.Create(Application.CommonAppDataPath + "\\TransferSettings.xml", settings);
            base.Serialize(writer, data);
            writer.Close();
        }

        public TransferSettings Deserialize()
        {
            TransferSettings _data;
            try
            {
                XmlReader reader = XmlReader.Create(Application.CommonAppDataPath + "\\TransferSettings.xml");
                _data = (TransferSettings)base.Deserialize(reader);
                reader.Close();
            }
            catch (System.Exception ex)
            {
                _data = new TransferSettings();
            }

            return _data;
        }
    }
}
