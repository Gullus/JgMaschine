﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Datafox;

namespace DataExport
{
    public partial class DataExport : Form
    {
        FormConnectionSettings _formConnectionSettings = new FormConnectionSettings();
        ConnectionSettingsSerializer _serializerConnectionSettings = new ConnectionSettingsSerializer();

        public DataExport()
        {
            InitializeComponent();
        }

        private void buttonConnection_Click(object sender, EventArgs e)
        {
            DialogResult result = _formConnectionSettings.ShowDialog(this);
        }

        private void buttonReadRecord_Click(object sender, EventArgs e)
        {
            ConnectionSettings settings = _serializerConnectionSettings.Deserialize();
            string msg;
            byte[] buf = new byte[256];
            int length, errorID = 0, result;
            StringBuilder errorString = new StringBuilder(255);

            // Verbindung zu Gerät herstellen
            if (DFComDLL.DFCComOpenIV(settings.ChannelID, 31, settings.Values.CommType, settings.Values.CommString, settings.Values.CommValue, settings.Values.CommTimeout) == 0)
            {
                msg = string.Format("Schnittstelle oder Verbindung zum Gerät konnte nicht geöffnet werden.\n\nBitte überprüfen Sie die Einstellungen der Kommunikation und Erreichbarkeit des Terminals.");
                MessageBox.Show(msg, "DFCComOpenIV schlug fehl!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }

            // Schleife nur um mit break abzubrechen, kein goto verwenden.
            do 
            {
                // Lesen der Datensatzbeschreibungen, diese stellen die Tabellendefinitionen dar.
                TableDeclarations records = new TableDeclarations(TableDeclarations.TableType.Record, "Records.xml");
                if (records.LoadFromDevice(settings.ChannelID, settings.DeviceID, "") == false)
                {
                    // Fehlertext ermitteln
                    DFComDLL.DFCGetErrorText(settings.ChannelID, errorID, 0, errorString, errorString.Capacity);
                    // Nachricht anzeigen
                    msg = string.Format("Lesen der Datensatzbeschreibung ist fehlgeschlagen.\n\nZurückgelieferte Fehlerbeschreibung:\n{0}", errorString);
                    MessageBox.Show(msg, "DFCLoadListenbeschreibung schlug fehl!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    break;
                }
                if (records.Tables == null)
                {
                    // Es liegen keine Datensatzbeschreibungen vor.
                    msg = string.Format("Es liegen keine Datensatzbeschreibungen vor.\n\nBitte prüfen Sie das eingespielte Setup.}");
                    MessageBox.Show(msg, "DFCLoadDatensatzbeschreibung", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    break;
                }

                textOut.Text = "";
                StringBuilder sb = new StringBuilder();
                do 
                {
                   length = buf.Length;
                    // Datensatz lesen
                    if ((result = DFComDLL.DFCReadRecord(settings.ChannelID, settings.DeviceID, buf, out length, out errorID)) < 0)
                    {
                        msg = string.Format("Datensatz konnte nicht gelesen werden. Fehlercode: {0}", errorID);
                        MessageBox.Show(msg, "DFCReadRecord schlug fehl!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                        break;
                    }

                    if (result == 0)
                    {
                       // msg = string.Format("Es liegt kein Datensatz vor");
                        //MessageBox.Show(msg, "DFCReadRecord", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        break;
                    }

                    DFRecord rs = new DFRecord(buf, records);
                    sb.AppendLine(rs.TabbedString());

                    // Datensatz quittieren
                    if (DFComDLL.DFCQuitRecord(settings.ChannelID, settings.DeviceID, out errorID) < 0)
                    {
                        msg = string.Format("Datensatz konnte nicht quittiert werden. Fehlercode: {0}", errorID);
                        MessageBox.Show(msg, "DFCQuitRecord schlug fehl!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                        break;
                    }
                } while (true);
 
                if (sb.Length > 0)
                {
                    textOut.Text = sb.ToString();
                }
            } while (false);

            // Verbindung schliessen
            DFComDLL.DFCComClose(settings.ChannelID);
        }

    }
}
