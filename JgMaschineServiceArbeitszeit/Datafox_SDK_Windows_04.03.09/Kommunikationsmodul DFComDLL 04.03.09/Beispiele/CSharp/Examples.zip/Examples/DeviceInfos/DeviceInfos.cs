﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Datafox;
using System.Diagnostics;

namespace DeviceInfos
{
    public partial class FormDeviceInfo : Form
    {
        public FormDeviceInfo()
        {
            InitializeComponent();
        }

        private void buttonGet_Click(object sender, EventArgs e)
        {
            int channelID = 1, 
                deviceID = 254, errorID, serialNumber = 0;
            StringBuilder version = new StringBuilder(64);
            StringBuilder passwordKey = new StringBuilder(64);
            byte[] dt = new byte[7];
            int len, flashStatus = 0;

            // Schnittstelle öffnen, Verbindung zum Gerät herstellen.
            if (DFComDLL.DFCComOpenIV(channelID, 31, 1, "COM1", 38400, 1000) == 1)
            {
                do
                {
                    // Ermittlung der Firmwareversion
                    if (DFComDLL.DFCGetVersionFirmware(channelID, deviceID, version, out errorID) == 0)
                    {
                        break;
                    }
                    // Ermittlung der Seriennummer
                    if (DFComDLL.DFCGetSeriennummer(channelID, deviceID, out errorID, out serialNumber) == 0)
                    {
                        break;
                    }
                    // Ermittlung der Systemzeit
                    if (DFComDLL.DFCComGetTime(channelID, deviceID, dt) == 0)
                    {
                        break;
                    }
                    len = passwordKey.MaxCapacity;
                    // Ermittlung des Passwortschlüssels
                    if (DFComDLL.DFCGetPasswordKey(channelID, deviceID, passwordKey, out len, out errorID) == 0)
                    {
                        break;
                    }
                    // Ermittlung des Flashstatus
                    if (DFComDLL.DFCGetFlashStatus(channelID, deviceID, out flashStatus, out errorID) == 0)
                    {
                        break;
                    }
                } while (false);

                // Werte in Controls übernehmen
                textFirmwareversion.Text = version.ToString();
                textSerialNumber.Text = string.Format("{0}", serialNumber);
                dateTimeSystem.Value = new DateTime(dt[0] * 100 + dt[1], dt[2], dt[3], dt[4], dt[5], dt[6]);
                if (passwordKey.Length > 0)
                {

                    textPasswordkey.Text = passwordKey.ToString();
               }
                else
                {

                    textPasswordkey.Text = "NA";
              }
                textFlashstatus.Text = string.Format("{0}", flashStatus);
            }

            DFComDLL.DFCComClose(channelID);
        }

        private void buttonConnection_Click(object sender, EventArgs e)
        {
            FormConnectionSettings dlg = new FormConnectionSettings();

            dlg.Show();
        }
    }
}
