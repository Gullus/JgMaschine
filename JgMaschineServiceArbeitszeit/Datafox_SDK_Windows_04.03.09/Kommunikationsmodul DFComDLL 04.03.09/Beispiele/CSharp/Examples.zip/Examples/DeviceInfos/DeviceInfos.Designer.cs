﻿namespace DeviceInfos
{
    partial class FormDeviceInfo
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonGet = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.textFirmwareversion = new System.Windows.Forms.TextBox();
            this.textSerialNumber = new System.Windows.Forms.TextBox();
            this.textPasswordkey = new System.Windows.Forms.TextBox();
            this.textFlashstatus = new System.Windows.Forms.TextBox();
            this.dateTimeSystem = new System.Windows.Forms.DateTimePicker();
            this.buttonConnection = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonGet
            // 
            this.buttonGet.Location = new System.Drawing.Point(184, 146);
            this.buttonGet.Name = "buttonGet";
            this.buttonGet.Size = new System.Drawing.Size(75, 23);
            this.buttonGet.TabIndex = 0;
            this.buttonGet.Text = "Ermitteln";
            this.buttonGet.UseVisualStyleBackColor = true;
            this.buttonGet.Click += new System.EventHandler(this.buttonGet_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Firmwareversion :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(26, 41);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Seriennummer :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(43, 68);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Systemzeit :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(7, 92);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(99, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "Passwortschlüssel :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(40, 118);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(66, 13);
            this.label5.TabIndex = 5;
            this.label5.Text = "Flashstatus :";
            // 
            // textFirmwareversion
            // 
            this.textFirmwareversion.Location = new System.Drawing.Point(112, 12);
            this.textFirmwareversion.Name = "textFirmwareversion";
            this.textFirmwareversion.Size = new System.Drawing.Size(146, 20);
            this.textFirmwareversion.TabIndex = 6;
            // 
            // textSerialNumber
            // 
            this.textSerialNumber.Location = new System.Drawing.Point(112, 38);
            this.textSerialNumber.Name = "textSerialNumber";
            this.textSerialNumber.Size = new System.Drawing.Size(146, 20);
            this.textSerialNumber.TabIndex = 7;
            // 
            // textPasswordkey
            // 
            this.textPasswordkey.Location = new System.Drawing.Point(112, 89);
            this.textPasswordkey.Name = "textPasswordkey";
            this.textPasswordkey.Size = new System.Drawing.Size(146, 20);
            this.textPasswordkey.TabIndex = 8;
            // 
            // textFlashstatus
            // 
            this.textFlashstatus.Location = new System.Drawing.Point(112, 115);
            this.textFlashstatus.Name = "textFlashstatus";
            this.textFlashstatus.Size = new System.Drawing.Size(146, 20);
            this.textFlashstatus.TabIndex = 9;
            // 
            // dateTimeSystem
            // 
            this.dateTimeSystem.CustomFormat = "yyyy_MM_dd hh:mm:ss";
            this.dateTimeSystem.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimeSystem.Location = new System.Drawing.Point(112, 64);
            this.dateTimeSystem.Name = "dateTimeSystem";
            this.dateTimeSystem.Size = new System.Drawing.Size(146, 20);
            this.dateTimeSystem.TabIndex = 10;
            // 
            // buttonConnection
            // 
            this.buttonConnection.Location = new System.Drawing.Point(10, 146);
            this.buttonConnection.Name = "buttonConnection";
            this.buttonConnection.Size = new System.Drawing.Size(75, 23);
            this.buttonConnection.TabIndex = 11;
            this.buttonConnection.Text = "Verbindung";
            this.buttonConnection.UseVisualStyleBackColor = true;
            this.buttonConnection.Click += new System.EventHandler(this.buttonConnection_Click);
            // 
            // FormDeviceInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(271, 181);
            this.Controls.Add(this.buttonConnection);
            this.Controls.Add(this.dateTimeSystem);
            this.Controls.Add(this.textFlashstatus);
            this.Controls.Add(this.textPasswordkey);
            this.Controls.Add(this.textSerialNumber);
            this.Controls.Add(this.textFirmwareversion);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonGet);
            this.Name = "FormDeviceInfo";
            this.Text = "Ermittlung Gerätespezifischer Informationen";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonGet;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textFirmwareversion;
        private System.Windows.Forms.TextBox textSerialNumber;
        private System.Windows.Forms.TextBox textPasswordkey;
        private System.Windows.Forms.TextBox textFlashstatus;
        private System.Windows.Forms.DateTimePicker dateTimeSystem;
        private System.Windows.Forms.Button buttonConnection;
    }
}

