﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Datafox;

namespace ModemConnections
{
    public partial class ModemConnections : Form
    {
        public ModemConnections()
        {
            InitializeComponent();
        }

        private void btnCommand_Click(object sender, EventArgs e)
        {
            if (DFComDLL.DFCComOpenIV(1, 31, 1, "COM1", 38400, 1000) == 1)
            {
                string str;
                int lengthWrite, lengthRead, errorID;
                StringBuilder sb = new StringBuilder();

                str = "ati\r\n";
                DFComDLL.DFCWrite(1, str, str.Length, out lengthWrite, out errorID);

                sb.Length = 250;
                DFComDLL.DFCRead(1, sb, sb.Length, out lengthRead, out errorID);

                IntPtr hComPort = DFComDLL.DFCGetComPort(1);
                DFComDLL.DFCSetComPort(1, hComPort, 0, 38400, 5000);

                DFComDLL.DFCWrite(1, str, str.Length, out lengthWrite, out errorID);
                sb.Length = 0;
                sb.Length = 250;

                DFComDLL.DFCRead(1, sb, sb.Length, out lengthRead, out errorID);

                DFComDLL.DFCComClose(1);
            }

        }
    }
}
